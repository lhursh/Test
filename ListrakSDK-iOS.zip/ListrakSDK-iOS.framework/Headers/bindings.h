#include "embeddinator.h"
#import <Foundation/Foundation.h>


#if !__has_feature(objc_arc)
#error Embeddinator code must be built with ARC.
#endif

#ifdef __cplusplus
extern "C" {
#endif
// forward declarations
@class iOSPlatformProvider;
@class Listrak_ListrakClientBase2;
@class Listrak_ListrakCredentialsBase2;
@class ListrakClient;
@class ListrakCredentials;


NS_ASSUME_NONNULL_BEGIN


/** Class iOSPlatformProvider
 *  Corresponding .NET Qualified Name: `iOSPlatformProvider, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface iOSPlatformProvider : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)init;


- (NSString *)getAppVersion;
- (NSString *)getHardwareID;
- (bool)getNotificationsEnabled;
- (NSString *)getOperatingSystem;
- (NSString *)getOperatingSystemVersion;
- (int)getPlatformType;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class Listrak_ListrakClientBase2
 *  Corresponding .NET Qualified Name: `Listrak.ListrakClientBase2, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface Listrak_ListrakClientBase2 : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

/** This type is not meant to be created using only default values
 *  Both the `-init` and `+new` selectors cannot be used to create instances of this type.
 */
- (nullable instancetype)init NS_UNAVAILABLE;
+ (nullable instancetype)new NS_UNAVAILABLE;


- (void)clickTrackingPushData:(NSString *)pushData;
- (NSString *)getHardwareID;
- (void)onAppInstall;
- (void)onAppUpgrade;
- (void)onEnterBackground;
- (void)onEnterForeground;
- (void)registerDeviceDeviceToken:(NSString *)deviceToken;
- (void)registerDeviceInformationDeviceToken:(NSString *)deviceToken;
- (void)setBirthdayBirthday:(NSString *)birthday;
- (void)setEmailEmail:(NSString *)email;
- (void)setFirstNameFirstName:(NSString *)firstName;
- (void)setLastNameLastName:(NSString *)lastName;
- (void)setMerchantIDMerchantID:(NSString *)merchantID;
- (void)setPhoneNumberPhoneNumber:(long long)phoneNumber;
- (void)setPostalCodePostalCode:(NSString *)postalCode;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class Listrak_ListrakCredentialsBase2
 *  Corresponding .NET Qualified Name: `Listrak.ListrakCredentialsBase2, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface Listrak_ListrakCredentialsBase2 : NSObject {
	// This field is not meant to be accessed from user code
	@public MonoEmbedObject* _object;
}

- (nullable instancetype)initWithIntegrationToken:(NSString *)integrationToken;

/** This type is not meant to be created using only default values
 *  Both the `-init` and `+new` selectors cannot be used to create instances of this type.
 */
- (nullable instancetype)init NS_UNAVAILABLE;
+ (nullable instancetype)new NS_UNAVAILABLE;


@property (nonatomic) NSString *integrationToken;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class ListrakClient
 *  Corresponding .NET Qualified Name: `ListrakClient, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface ListrakClient : Listrak_ListrakClientBase2 {
}

- (nullable instancetype)initWithIntegrationToken:(NSString *)integrationToken;

/** This type is not meant to be created using only default values
 *  Both the `-init` and `+new` selectors cannot be used to create instances of this type.
 */
- (nullable instancetype)init NS_UNAVAILABLE;
+ (nullable instancetype)new NS_UNAVAILABLE;


- (NSString *)getHardwareID;
- (void)registerDeviceDeviceToken:(NSString *)deviceToken;
- (void)registerDeviceInformationDeviceToken:(NSString *)deviceToken;
/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end


/** Class ListrakCredentials
 *  Corresponding .NET Qualified Name: `ListrakCredentials, ListrakSDK-iOS, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null`
 */
@interface ListrakCredentials : Listrak_ListrakCredentialsBase2 {
}

- (nullable instancetype)initWithIntegrationToken:(NSString *)integrationToken;

/** This type is not meant to be created using only default values
 *  Both the `-init` and `+new` selectors cannot be used to create instances of this type.
 */
- (nullable instancetype)init NS_UNAVAILABLE;
+ (nullable instancetype)new NS_UNAVAILABLE;

/** This selector is not meant to be called from user code
 *  It exists solely to allow the correct subclassing of managed (.net) types
 */
- (nullable instancetype)initForSuper;

@end

NS_ASSUME_NONNULL_END

#ifdef __cplusplus
} /* extern "C" */
#endif
